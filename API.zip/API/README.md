# My API

## Description
This API provides prediction and recommendation functionalities for Meally App. It is built using FastAPI, Python and Docker.

## Application
Dounload Docker app `https://www.docker.com/products/docker-desktop/`

## Installation
2. Navigate to the project directory: `cd your-api`
3. Create a virtual environment: `python -m venv venv`
4. Activate the virtual environment:
   - For Windows: `venv\Scripts\activate`
   - For macOS/Linux: `source venv/bin/activate`

## Installation using conda
1. Create a virtual environment: `conda create --name envname pyhton=3.9`
3. Activate the virtual environmet: `activate envname`
4. Navigate to the project directory: `cd your-directory`

## Creating the Image and Container
1. Create an image: `docker build -t imagename .`
2. Create a Container: `docker run -d --name mycontainer -p 80:80 imagename`


## Usage
2. Access the API endpoints:
   - Prediction: `http://localhost/docs#/default/predict_predict_post`
   - Recommendation: `http://localhost/docs#/default/recommend_recommend_post`
3. Click the "try it out" button and try it


## API  Documentation
For detailed information about the API endpoints and their usage, refer to the [API Documentation](docs/api-docs.md).

## API-DOCKER Documentation
For more detail about API-DOCKER visit `https://fastapi.tiangolo.com/deployment/docker/`


