"""
This module contains the model
"""
from pydantic import BaseModel

#  Class which describes Predictions
class PredictModel(BaseModel):
    distance: float 
    
#  Class which describes Recommendation   
class RecommendModel(BaseModel):
    customerID: int 
    