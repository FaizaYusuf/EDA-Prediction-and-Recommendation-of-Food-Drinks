from fastapi import FastAPI
import uvicorn
import pickle
import numpy as np
from recommendation import get_recommendations
from Model import PredictModel, RecommendModel

app = FastAPI(debug=True)

@app.get('/')
def home():
    return {"text": "Welcome to meally prediction and recommendation!!"}



# the  the time taken prediction
@app.post('/predict')
def predict(distance: PredictModel):
    """ this function use the distance and return the predicted time taken for the food to be delivered to the customer 
        parameter:
                distance-> the distance between the restaurant and the customer place, it is in float
    """
    
    model = pickle.load(open("Pickle Files/model.pkl","rb")) # loading pickle file with the prediction model
    prediction = model.predict([[distance.distance]])  #predictiong
    output = np.round(prediction).astype(int)
    return {f"The estimated time for your dilivery is {output} minutes" }


    
# the recommendation funtion
@app.post('/recommend')
def recommend(customer_id: RecommendModel):
    """ this function accept the customer id and returns the top ten recommended food tfor a cusomer"""
    recommend_list = get_recommendations(customer_id=customer_id.customerID)  # get recommmendation is gotten from the recommendation module
    return {f"The Top ten recommended list are: {recommend_list}"}


# try running it trough uvicorn
if __name__ == '__name__':
    uvicorn.run(app, host='127.0.0.1', port=8000)
    
#uvicorn app:app --reload (use this statement on cmd to test the api usin uvicon)