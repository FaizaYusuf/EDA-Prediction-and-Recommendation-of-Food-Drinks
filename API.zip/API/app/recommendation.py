
import pickle
import pandas as pd

# his module ontains the 



# load the data and similarity pickle files from Pickle FAiles
df = pickle.load(open("Pickle Files/data.pkl","rb"))
cosine_similarity  = pickle.load(open("Pickle Files/similarityV2.pkl","rb"))


def get_recommendations(*, customer_id):
    """ This function get the product recommendation for a specified user based in his/her last orde
    """
    recommended_items = []
    # if customer made order
    if customer_id in df["customer_id"].to_list():
        # get customer's last order item
        customer_last_order = (df[df["customer_id"] == customer_id]["product"]).to_list()[-1]
        
        # get all the product with no duplicates
        indices = pd.Series(df["product"].str.strip()).drop_duplicates()
        indices = pd.Series(indices.index, index=indices.values)
        
        idx = indices[customer_last_order] # get the product indices of the customer's last order
        sim = enumerate(cosine_similarity[idx]) # check the similarities
        sim = sorted(sim, key=lambda x: x[1], reverse=True) # sort similarities in descending
        
        
        sim_index = [i[0] for i in sim] # get the product index from the similarities  
        sim_data = (df["product"].iloc[sim_index]).drop_duplicates() # get the product name using the index
        top_10 = sim_data[:10].values.tolist() # get the top ten
        
        # get the product with the heighest rating alon with the retaurant name
        for i in top_10: 
            details = df[df["product"]== i].sort_values(by="product_rating", ascending=False)[
                ["product","place_name"]].values[0].tolist()
            recommended_items.append(details)
    
    # if customer has not make any order yet recommend the top ten products with highest rating
    else:
        recommended_items = df.sort_values(by="product_rating",
                                            ascending=False)[["product","place_name"]].drop_duplicates().values[:10].tolist()
    return recommended_items

    
    